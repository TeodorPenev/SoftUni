﻿namespace NightlifeEntertainment
{
    using System;

    public enum TicketStatus
    {
        Sold,
        Unsold
    }
}
