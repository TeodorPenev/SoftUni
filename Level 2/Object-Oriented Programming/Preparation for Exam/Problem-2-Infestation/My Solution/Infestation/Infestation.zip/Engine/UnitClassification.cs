﻿namespace Infestation.Engine
{
    public enum UnitClassification
    {
        Biological,
        Mechanical,
        Psionic,
        Unknown
    }
}
