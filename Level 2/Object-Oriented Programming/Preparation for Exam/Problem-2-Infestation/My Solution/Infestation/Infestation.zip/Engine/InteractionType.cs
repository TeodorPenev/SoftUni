﻿namespace Infestation.Engine
{
    public enum InteractionType
    {
        Attack,
        Infest,
    }
}
