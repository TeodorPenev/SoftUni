<?php
$groups = array(1=>'Friends', 2=>'Ex-',
    3=>'Future', 4=>'Colleagues', 5=>'Family');
?>
