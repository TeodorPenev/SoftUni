<?php
require 'constants.php';
?>
<!DOCTYPE html>
<html>
    <head>
        <title><?= $pageTitle;?></title>
        <meta charset="UTF-8">       
    </head>
    <body>