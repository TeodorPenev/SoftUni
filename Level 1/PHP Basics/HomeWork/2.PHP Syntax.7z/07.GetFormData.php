</<!doctype html>
<head>
    <meta charset="UTF-8">
    <title>Get Form Data</title>
</head>
<body>
<form action="" method="post">
<input type="text" name="name" placeholder="Name..."><br>
<input type="text" name="age" placeholder="Age..."><br>
<input type="radio" name="butS" value="male"> Male<br>
<input type="radio" name="butS" value="female"> Female<br>
    <input type="submit">
</form>

<?php if (isset($_POST['name'], $_POST['age'], $_POST['butS'])):?>
    <p>
        My name is <?= htmlentities($_POST['name']) ?>. I am <?= htmlentities($_POST['age']) ?> years old. I am <?= htmlentities($_POST['butS']) ?>.
    </p>
<?php endif; ?>
</body>
</html>

