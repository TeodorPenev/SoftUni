<?php
$firstNumber =1234.5678;
$secondNumber =333;

echo(number_format( $firstNumber+$secondNumber,2,'.',''));
?>