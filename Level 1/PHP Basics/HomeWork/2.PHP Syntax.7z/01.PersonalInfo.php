<?php
$firstName ="Steve";
$lastName ="Jobs";
$age = 27;
$fullName ="$firstName $lastName";
echo "My name is $fullName and I am $age years old.";
?>