﻿function reverseString(str) {
    var strRev = str.split('').reverse().join('');
    console.log(strRev);
}

reverseString('sample');
reverseString('softUni');
reverseString('java script');