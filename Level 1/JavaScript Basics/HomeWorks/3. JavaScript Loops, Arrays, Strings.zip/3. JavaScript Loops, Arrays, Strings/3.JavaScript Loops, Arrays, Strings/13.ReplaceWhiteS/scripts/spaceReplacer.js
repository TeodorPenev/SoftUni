﻿function replaceSpaces(str) {
    var pattern ='';
    var replaceStr = str.replace(/[\s]/g, pattern);
    console.log(replaceStr);
}

replaceSpaces('But you were living in another world tryin\' to get your message through')