﻿    document.getElementById("r1").innerHTML += Math.PI * Math.pow(7, 2);
    document.getElementById("r2").innerHTML += Math.PI * Math.pow(1.5, 2);
    document.getElementById("r3").innerHTML += Math.PI * Math.pow(20, 2);
