﻿# 05.DecimalToHexadecimal


