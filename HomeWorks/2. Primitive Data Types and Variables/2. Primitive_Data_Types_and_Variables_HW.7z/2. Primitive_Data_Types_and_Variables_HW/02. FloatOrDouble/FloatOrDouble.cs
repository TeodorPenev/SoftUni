﻿using System;
class FloatOrDouble
{
    static void Main()
    {
        double v1 = 34.567839023;
        float v2 = 12.345f;
        double v3 = 8923.1234857;
        float v4 = 3456.091f;
        Console.WriteLine("{0}\n{1}\n{2}\n{3}",v1,v2,v3,v4);
    }
}

