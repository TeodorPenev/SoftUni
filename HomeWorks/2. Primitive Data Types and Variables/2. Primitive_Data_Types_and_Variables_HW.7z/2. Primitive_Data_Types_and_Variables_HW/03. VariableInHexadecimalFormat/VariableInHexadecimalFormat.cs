﻿using System;
class VariableInHexadecimalFormat
{
    static void Main()
    {
        int varInHex = 0xFE;
        Console.WriteLine(varInHex);
    }
}
