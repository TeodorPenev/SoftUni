﻿using System;
class DeclareVariables
{
    static void Main()
    {
        ushort v1 = 52130;
        sbyte v2 = -115;
        int v3 = 4825932;
        byte v4 = 97;
        short v5 = -10000;
        Console.WriteLine("{0}\n{1}\n{2}\n{3}\n{4}", v1, v2, v3, v4, v5);
    }
}

