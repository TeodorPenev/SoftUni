﻿using System;
using System.Text;
class IsoscelesTriangle
{
    static void Main()
    {
        Console.OutputEncoding = Encoding.UTF8;
        Console.Write(@"   ©
  © ©
 ©   ©
© © © ©
");
    }
}

