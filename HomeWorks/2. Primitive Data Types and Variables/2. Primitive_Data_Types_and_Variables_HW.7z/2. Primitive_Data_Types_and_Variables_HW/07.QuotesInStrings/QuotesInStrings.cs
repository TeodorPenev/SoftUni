﻿using System;

class QuotesInStrings
{
    static void Main()
    {
        string var1 = "The \"use\" of quotations causes difficultes.";
        string var2 = "The use of quotations causes difficultes.";
        Console.WriteLine(var1);
        Console.WriteLine(var2);
    }
}

