﻿using System;
namespace _10.EmployeeData
{
    class EmployeeData
    {
        static void Main()
        {
            string firstName = "Steve";
            string lastName = "Jobs";
            byte age = 55;
            char gender = 'm';
            string personalIDNumber = "054544847";
            string employeeNumber = "2756000";
            Console.WriteLine(firstName);
            Console.WriteLine(lastName);
            Console.WriteLine(age);
            Console.WriteLine(gender);
            Console.WriteLine(personalIDNumber);
            Console.WriteLine(employeeNumber);
        }
    }
}
