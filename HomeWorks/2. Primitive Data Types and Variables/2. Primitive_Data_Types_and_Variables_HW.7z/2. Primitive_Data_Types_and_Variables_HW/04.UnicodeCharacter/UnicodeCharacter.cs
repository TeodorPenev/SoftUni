﻿using System;
class UnicodeCharacter
{
    static void Main()
    {
        char uniCodeVar = '\u002A';
        Console.WriteLine(uniCodeVar);
    }
}

