﻿using System;

    class SquareRoot
    {
        static void Main()
        {
            int n = 12345;
            Console.WriteLine("{0}",Math.Sqrt(n));
        }
    }

